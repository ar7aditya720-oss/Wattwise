import io, os, tempfile, unittest
from fastapi.testclient import TestClient
from app import database
from app.main import app
class BackendAPITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(); database.DB_PATH=os.path.join(cls.tmp.name,'test.db'); database.init_db(); cls.client=TestClient(app)
    @classmethod
    def tearDownClass(cls): cls.tmp.cleanup()
    def test_health(self): self.assertEqual(self.client.get('/health').json()['status'],'ok')
    def test_upload_analysis_and_history(self):
        csv=b'timestamp,kwh\n2026-10-01T00:00:00Z,1\n2026-10-01T01:00:00Z,2\n2026-10-01T02:00:00Z,1\n2026-10-01T03:00:00Z,1\n'
        r=self.client.post('/api/analyze',files={'file':('readings.csv',io.BytesIO(csv),'text/csv')},data={'electricity_rate':'10','avoidable_percent':'50'})
        self.assertEqual(r.status_code,200,r.text); self.assertEqual(r.json()['result']['summary']['total_energy_kwh'],5.0)
        self.assertGreaterEqual(len(self.client.get('/api/analyses').json()['items']),1)
    def test_reject_non_csv(self):
        r=self.client.post('/api/analyze',files={'file':('readings.txt',io.BytesIO(b'hello'),'text/plain')}); self.assertEqual(r.status_code,415)
if __name__=='__main__': unittest.main()
